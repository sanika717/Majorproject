"""Tiny stdlib HTTP helper (no extra dependency)."""
import urllib.request
import urllib.error

UA = "UrbanPulse-ESG-Updater/1.0 (+civic transparency project)"


class UpdateError(Exception):
    """A source could not be fetched/understood. The job is logged as failed and NO data is written."""


def fetch(url: str, timeout: int = 30, method: str = "GET") -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (fixed https source URLs)
            return r.read()
    except urllib.error.HTTPError as e:
        raise UpdateError(f"HTTP {e.code} from {url.split('?')[0]}") from e
    except Exception as e:  # DNS, timeout, TLS ...
        raise UpdateError(f"{type(e).__name__}: {e} ({url.split('?')[0]})") from e
