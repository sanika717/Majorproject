/**
 * UrbanPulse - ESG Scoring (UrbanPulse ESG Composite Score)
 * Reads ONLY existing verified datasets (window.URBANPULSE_DATA, window.URBANPULSE_CONSTRUCTION_DATA)
 * plus one clearly-labelled external sourced figure (PM2.5). Missing data stays null and is shown as
 * "Data Not Available"; it is never converted to 0. Weights of unavailable metrics are re-normalised
 * across the metrics that ARE available.
 */
(function () {
  "use strict";
  var D = window.URBANPULSE_DATA, C = window.URBANPULSE_CONSTRUCTION_DATA;

  // ---- Tunable constants (documented on the page) --------------------------------------------
  var ESG_WEIGHTS = { E: 0.3333, S: 0.3333, G: 0.3334 };
  var PM25 = { value: 33, min: 5, max: 40,
    url: "https://eparlib.nic.in/bitstream/123456789/2979976/1/AU20_I7PyWX.pdf",
    src: "Lok Sabha reply, Ministry of Environment (Jul 2024) - external source, not from UrbanPulse EDA" };
  var YEARS = ["2021", "2022", "2023"], LATEST = "2023";

  var clamp = function (v) { return Math.max(0, Math.min(100, v)); };
  var norm = function (a, mn, mx) { return mx === mn ? null : clamp((a - mn) / (mx - mn) * 100); };
  var inv = function (a, mn, mx) { var n = norm(a, mn, mx); return n === null ? null : clamp(100 - n); };
  var isNum = function (v) { return typeof v === "number" && isFinite(v); };
  var f1 = function (v) { return isNum(v) ? v.toFixed(1) : "Data Not Available"; };
  var NA = "Data Not Available";

  function yearly(cat, field) {
    try {
      var y = D.categories[cat].years;
      var vals = YEARS.map(function (k) { return y[k] ? y[k][field] : undefined; });
      return vals.every(isNum) ? vals : null;
    } catch (e) { return null; }
  }
  function numberedWards() {
    var arr = (C && C.ward_level_data) || [];
    return arr.filter(function (w) { var n = Number(w.ward); return /^\d+$/.test(String(w.ward)) && n >= 1 && n <= 198; });
  }

  // ---- Official imports (frontend/data/esg/official_metrics.csv) -----------------------------
  // Columns: metric_id,year,value,unit,source_name,source_url   (see data/esg/README.md)
  var OFF = {}, CSV_FILE = "data/esg/official_metrics.csv";
  var yk = function (y) { var m = String(y).match(/\d{4}/); return m ? +m[0] : 0; };
  function parseCSV(t) {
    var L = t.replace(/\r/g, "").split("\n").filter(function (l) { return l.trim() && l.charAt(0) !== "#"; });
    if (L.length < 2) return;
    var h = L[0].split(",").map(function (x) { return x.trim(); });
    L.slice(1).forEach(function (l) {
      var c = l.split(","), r = {}; h.forEach(function (k, i) { r[k] = (c[i] || "").trim(); });
      r.value = parseFloat(r.value);
      if (r.metric_id && isFinite(r.value)) (OFF[r.metric_id] = OFF[r.metric_id] || []).push(r);
    });
  }
  function loadOfficial() {
    if (typeof fetch !== "function" || typeof document === "undefined") return Promise.resolve();
    return fetch(CSV_FILE, { cache: "no-store" }).then(function (r) { return r.ok ? r.text() : ""; }).then(parseCSV).catch(function () {});
  }
  function latestOff(id) {
    var r = OFF[id]; if (!r || !r.length) return null;
    return r.slice().sort(function (a, b) { return yk(b.year) - yk(a.year); })[0];
  }
  var GHG = null;
  function addOfficial(rows) { rows.forEach(function (r) { if (!OFF[r.metric_id] && isFinite(r.value)) OFF[r.metric_id] = [r]; }); }
  function setGhg(g) { GHG = g; }
  var PENDING = "Data Pending Import";
  function pendingMetric(name, weight, dir, id, why) {
    return { name: name, source: why, weight: weight, direction: dir, pending: true, score: null, actual: PENDING,
      period: "-", method: "Add rows for metric_id '" + id + "' to " + CSV_FILE };
  }
  var SPEC = { // official-source metrics: bounds + direction
    pm25: { n: "PM2.5 annual mean (ug/m3)", mn: 5, mx: 40, low: true, u: " ug/m3", m: "Inverse min-max: WHO 2021 guideline (5) to India NAAQS annual limit (40)" },
    pm10: { n: "PM10 annual mean (ug/m3)", mn: 15, mx: 60, low: true, u: " ug/m3", m: "Inverse min-max: WHO 2021 guideline (15) to India NAAQS annual limit (60)" },
    no2: { n: "NO2 annual mean (ug/m3)", mn: 10, mx: 40, low: true, u: " ug/m3", m: "Inverse min-max: WHO 2021 guideline (10) to India NAAQS annual limit (40)" },
    water_quality_index: { n: "Lake water quality: % station-months Satisfactory (KSPCB)", mn: 0, mx: 100, low: false, u: "%", m: "Min-max on 0-100 % of monitored lake station-months rated Satisfactory (higher = better)" },
    water_supply_coverage_pct: { n: "Water supply coverage (%)", mn: 0, mx: 100, low: false, u: "%", m: "Min-max on 0-100 % (higher = better)" },
    ncrb_chargesheet_rate_pct: { n: "NCRB chargesheeting rate (%)", mn: 0, mx: 100, low: false, u: "%", m: "Min-max on 0-100 % (higher = better)" }
  };
  function officialMetric(id, weight, fallback) {
    var sp = SPEC[id], r = latestOff(id);
    if (!r) return fallback || pendingMetric(sp.n, weight, sp.low ? "Lower is better" : "Higher is better", id, "Official dataset not yet imported");
    var m = { name: sp.n, source: r.source_name || "Official dataset", link: r.source_url, weight: weight, official: true,
      direction: sp.low ? "Lower is better" : "Higher is better", method: sp.m, period: r.year,
      actual: r.value + sp.u + " (" + r.year + ")" };
    m.score = sp.low ? inv(r.value, sp.mn, sp.mx) : norm(r.value, sp.mn, sp.mx);
    return m;
  }

  // ---- Metric builders ---------------------------------------------------------------------------
  function seriesOf(cat, field, offId) {
    var rows = OFF[offId];
    if (rows && rows.length >= 2) {
      var s = rows.slice().sort(function (a, b) { return yk(a.year) - yk(b.year); });
      return { labels: s.map(function (r) { return String(r.year); }), vals: s.map(function (r) { return r.value; }), official: true,
        source: s[0].source_name || "Official dataset", link: s[0].source_url };
    }
    var v = yearly(cat, field);
    return v ? { labels: YEARS.slice(), vals: v, official: false, source: "Bengaluru City Police press note 2021-2023 (data.js) - fallback until official NCRB rows are imported" } : null;
  }
  function negMetric(name, cat, field, offId, weight) {
    var se = seriesOf(cat, field, offId), m = { name: name, weight: weight, direction: "Lower is better",
      method: "Inverse min-max over the series years: 100 - ((x - min)/(max - min) x 100); latest year scored" };
    if (!se) { m.score = null; m.actual = NA; m.source = "-"; m.period = "-"; return m; }
    var v = se.vals, mn = Math.min.apply(null, v), mx = Math.max.apply(null, v), last = v[v.length - 1];
    m.source = se.source; m.link = se.link; m.official = se.official; m.series = se;
    m.period = se.labels[0] + "-" + se.labels[se.labels.length - 1] + " (scored: " + se.labels[se.labels.length - 1] + ")";
    m.actual = last.toLocaleString("en-IN") + " reported cases (range " + mn.toLocaleString("en-IN") + "-" + mx.toLocaleString("en-IN") + ")";
    m.score = inv(last, mn, mx);
    return m;
  }
  function coverage(name, weight, key, label) {
    var w = numberedWards(), total = C && C.overview ? C.overview.official_wards_total : null, m = { name: name,
      source: "BBMP 2025-26 work orders (project dataset, construction-data.js)", weight: weight, direction: "Higher is better", period: "FY 2025-26",
      method: "Covered wards / 198 x 100 (already 0-100)" };
    if (!w.length || !isNum(total)) { m.score = null; m.actual = NA; return m; }
    var n = w.filter(function (x) { return Number(x[key]) > 0; }).length;
    m.actual = n + " of " + total + " wards " + label; m.score = clamp(n / total * 100);
    return m;
  }
  function unavailable(name, weight, why) {
    return { name: name, source: why, weight: weight, actual: NA, score: null, direction: "-", period: "-", method: "Excluded; weight re-normalised" };
  }

  function buildMetrics() {
    var cs = "Bengaluru City Police press note 2021-2023 (data.js)";
    var pm = officialMetric("pm25", 0.20, (function () { var m = { name: SPEC.pm25.n, source: PM25.src, link: PM25.url, weight: 0.20, external: true,
        direction: "Lower is better", method: SPEC.pm25.m + " (fallback figure until OGD rows are imported)", period: "Jul 2024 reply; data year not stated",
        actual: PM25.value + " ug/m3" }; m.score = inv(PM25.value, PM25.min, PM25.max); return m; })());
    var env = [pm, officialMetric("pm10", 0.10), officialMetric("no2", 0.10), officialMetric("water_quality_index", 0.15),
      officialMetric("water_supply_coverage_pct", 0.15),
      GHG ? { name: "GHG emissions (million tCO2e)", source: GHG.source_name, link: GHG.source_url, weight: 0.10, direction: "Lower is better", period: String(GHG.year), notScored: true,
        actual: GHG.value + " million tCO2e (" + GHG.year + ", BBMP area)", score: null, method: "Reported only: one inventory year and no official benchmark, so no defensible normalization; excluded from the score" }
        : unavailable("GHG emissions (tCO2e)", 0.10, "BBMP Climate Action Plan 2019 inventory total not imported"),
      coverage("Water-project ward coverage", 0.10, "water_projects", "with a water work order"),
      coverage("Drainage-project ward coverage", 0.10, "drain_projects", "with a drainage work order")];
    var soc = [
      negMetric("Crimes against women (reported)", "women", "total_reported", "women_cases", 0.25),
      negMetric("Crimes against children (reported)", "children", "total_reported", "children_cases", 0.25),
      negMetric("Cyber crime (reported)", "cyber", "total_reported", "cyber_cases", 0.20),
      negMetric("Suicides", "suicides", "total_suicides", "suicides_cases", 0.10),
      negMetric("Accidental deaths", "accidental", "total_accidental_deaths", "accidental_cases", 0.10),
      officialMetric("ncrb_chargesheet_rate_pct", 0.10)];
    var gov = [];
    (function () {
      var m = { name: "Detection rate: women + children crimes", source: cs, weight: 0.30, direction: "Higher is better", period: "2023",
        method: "Detected / reported x 100 (already 0-100)" };
      var wd = yearly("women", "total_detected"), wr = yearly("women", "total_reported"),
          cd = yearly("children", "total_detected"), cr = yearly("children", "total_reported");
      if (wd && wr && cd && cr) { var r = (wd[2] + cd[2]) / (wr[2] + cr[2]) * 100; m.actual = r.toFixed(2) + "%"; m.score = clamp(r); }
      else { m.actual = NA; m.score = null; }
      gov.push(m);
    })();
    (function () {
      var m = { name: "Contractor diversity (contractors per work order)", source: "BBMP 2025-26 work orders (project dataset, construction-data.js)",
        weight: 0.25, direction: "Higher is better", period: "FY 2025-26", method: "Unique contractors / work orders x 100 (proxy; 100 = no repeat contractors)" };
      var o = C && C.overview;
      if (o && isNum(o.unique_contractors) && o.total_work_orders > 0) {
        m.actual = o.unique_contractors.toLocaleString("en-IN") + " contractors / " + o.total_work_orders.toLocaleString("en-IN") + " orders";
        m.score = clamp(o.unique_contractors / o.total_work_orders * 100);
      } else { m.actual = NA; m.score = null; }
      gov.push(m);
    })();
    gov.push(coverage("Work-order ward coverage", 0.25, "total_work_orders", "with at least one work order"));
    gov.push(pendingMetric("Public complaint resolution", 0.20, "Higher is better", "-", "No verified complaint dataset in the project"));
    gov[3].pending = false; gov[3].actual = NA;
    return { E: env, S: soc, G: gov };
  }

  function scoreComponent(list) {
    var avail = list.filter(function (m) { return isNum(m.score); });
    var wsum = avail.reduce(function (s, m) { return s + m.weight; }, 0);
    list.forEach(function (m) { m.effW = isNum(m.score) && wsum > 0 ? m.weight / wsum : null; m.contrib = isNum(m.effW) ? m.score * m.effW : null; });
    var score = avail.length && wsum > 0 ? avail.reduce(function (s, m) { return s + m.contrib; }, 0) : null;
    var cov = avail.length === 0 ? "Not Available" : (avail.length === list.length ? "Available" : "Partial");
    return { score: score, coverage: cov, used: avail.length, total: list.length };
  }

  function compute() {
    var M = buildMetrics(), comp = { E: scoreComponent(M.E), S: scoreComponent(M.S), G: scoreComponent(M.G) };
    var keys = ["E", "S", "G"].filter(function (k) { return isNum(comp[k].score); });
    var wsum = keys.reduce(function (s, k) { return s + ESG_WEIGHTS[k]; }, 0);
    keys.forEach(function (k) { comp[k].effW = ESG_WEIGHTS[k] / wsum; comp[k].contrib = comp[k].score * comp[k].effW; });
    var overall = keys.length ? keys.reduce(function (s, k) { return s + comp[k].contrib; }, 0) : null;
    return { metrics: M, comp: comp, overall: overall };
  }

  function band(s) {
    if (!isNum(s)) return { label: NA, color: "var(--text-muted)" };
    if (s >= 80) return { label: "Excellent", color: "var(--accent-emerald)" };
    if (s >= 60) return { label: "Good", color: "var(--accent-cyan)" };
    if (s >= 40) return { label: "Moderate", color: "var(--accent-amber)" };
    return { label: "Needs Improvement", color: "var(--accent-rose)" };
  }

  window.URBANPULSE_ESG = { compute: compute, band: band, addOfficial: addOfficial, setGhg: setGhg };
  if (typeof document === "undefined") return;

  // ---- Rendering ---------------------------------------------------------------------------------
  var COL = { E: "#10b981", S: "#38bdf8", G: "#6366f1" };
  var NAMES = { E: "Environmental", S: "Social", G: "Governance" };
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };

  function render() {
    var R = compute();
    ["E", "S", "G"].forEach(function (k) {
      var el = $("esg-" + k + "-value"), s = R.comp[k].score;
      el.closest(".kpi-card").hidden = !isNum(s);
      el.innerHTML = isNum(s) ? f1(s) + ' <span class="esg-of">/ 100</span>' : "";
      $("esg-" + k + "-sub").textContent = "";
    });
    $("esg-O-value").closest(".kpi-card").hidden = !isNum(R.overall);
    $("esg-O-value").innerHTML = isNum(R.overall) ? f1(R.overall) + ' <span class="esg-of">/ 100</span>' : "";
    var b = band(R.overall), be = $("esg-O-band");
    be.textContent = isNum(R.overall) ? b.label : "";
    be.style.color = b.color;
    be.style.borderColor = b.color;

    var html = "";
    ["E", "S", "G"].forEach(function (k) {
      var rows = R.metrics[k].filter(function (m) {
        return m.actual !== NA && m.actual !== PENDING && m.link;
      }).map(function (m) {
        return "<tr><td><strong>" + esc(m.name) + "</strong></td><td>" + esc(m.actual) + "</td>" +
          '<td><a href="' + esc(m.link) + '" target="_blank" rel="noopener noreferrer" style="color:var(--accent-cyan)">Dataset</a></td></tr>';
      }).join("");
      if (!rows) return;
      html += '<div class="table-card glass-panel esg-method"><div class="table-header-wrap"><h3 style="color:' + COL[k] + '">' + NAMES[k] + " &mdash; " +
        (isNum(R.comp[k].score) ? f1(R.comp[k].score) + " / 100" : "") + '</h3></div>' +
        '<div style="overflow-x:auto"><table class="custom-table"><thead><tr><th>Indicator</th><th>Value</th><th>Dataset</th></tr></thead><tbody>' + rows + "</tbody></table></div></div>";
    });
    $("esg-method-tables").innerHTML = html;

    charts(R); cyberChart(R);
  }

  function cyberChart(R) {
    var m = R.metrics.S.filter(function (x) { return x.series && /Cyber/.test(x.name); })[0], se = m && m.series;
    var source = $("esg-cyber-src");
    if (source) source.innerHTML = se && m.link ? '<a href="' + esc(m.link) + '" target="_blank" rel="noopener noreferrer">Dataset</a>' : "";
    chartOrNA("esg-chart-cyber", !!se && !!m.link, function (cv) {
      new Chart(cv, { type: "bar", data: { labels: se.labels, datasets: [{ data: se.vals, backgroundColor: COL.S, borderRadius: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } } });
    });
  }

  function chartOrNA(canvasId, ok, build) {
    var cv = $(canvasId), host = cv.parentNode;
    if (!ok || typeof Chart === "undefined") {
      var card = cv.closest(".chart-card");
      if (card) card.hidden = true;
      var grid = card && card.closest(".charts-grid");
      if (grid && !Array.prototype.some.call(grid.querySelectorAll(".chart-card"), function (item) { return !item.hidden; })) grid.hidden = true;
      return;
    }
    build(cv);
  }

  function charts(R) {
    if (typeof Chart !== "undefined") { Chart.defaults.color = "#94a3b8"; Chart.defaults.borderColor = "rgba(255,255,255,0.08)"; Chart.defaults.font.family = "Inter, sans-serif"; }
    var ks = ["E", "S", "G"].filter(function (k) { return isNum(R.comp[k].score); });
    chartOrNA("esg-chart-components", ks.length > 0, function (cv) {
      new Chart(cv, { type: "bar", data: { labels: ks.map(function (k) { return NAMES[k]; }),
        datasets: [{ data: ks.map(function (k) { return +R.comp[k].score.toFixed(1); }), backgroundColor: ks.map(function (k) { return COL[k]; }), borderRadius: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { min: 0, max: 100 } } } });
    });
  }

  document.addEventListener("DOMContentLoaded", function () { loadOfficial().then(function () { return window.ESG_ENV && window.ESG_ENV.start ? window.ESG_ENV.start().catch(function (e) { console.error("ESG env load failed:", e); }) : null; }).then(render); });
})();
