# ESG data (frontend/data/esg)

These JSON files are the verified ESG datasets. The backend seeds them into the database on startup
(`backend/app/services/esg_service.py`, tables `esg_*`) and the frontend falls back to them if the API is down.

| File | Content | Source |
|---|---|---|
| sources.json | Source URL, publisher, period for every dataset | - |
| air_quality_stations.json | 16 KSPCB manual stations, annual means 2016-17 (SO2, NO2, PM10, PM2.5, NH3, Pb, CO) | Guttikunda et al. 2019, Atmos. Pollut. Res., Table 2 |
| carbon_emissions.json | Bengaluru GHG 2019 total and sector shares | BBMP BCAP |
| water_quality_lakes_2020_21.json | Monthly class + WQI status, 106 stations | KSPCB MINARS CSV |
| electricity_consumption.json | Empty: no genuine area-wise data found | BESCOM / data.gov.in (reference only) |
| official_metrics.csv | Optional manual rows (see header) that override/extend scoring metrics | - |

To add data: edit the JSON (e.g. add `aqi` values or electricity `rows`), then run `python3 -m backend.scripts.seed_esg`
(or POST /api/v1/esg/reseed). Never add estimated values.

## Auto-update (Phase 1)
`backend/app/services/esg_update/` refreshes the database in the background (see its `scheduler.py` header for env vars).
Air = CPCB feed on data.gov.in (needs `DATA_GOV_IN_API_KEY`), electricity = BESCOM CSV via OpenCity, carbon/water = reload
when the verified JSON here changes. Check `GET /api/v1/esg/update-status`. Never add estimated values.
